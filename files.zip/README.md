<p align="center">
  <img src="assets/logo.png" alt="PR’67 logo" width="160">
</p>

<h1 align="center">PR’67 Visual Production</h1>

<p align="center">Videography · Video Editing · Cinematic Storytelling</p>

## Project structure

```
├── index.html
├── README.md
└── assets/
    ├── logo.png
    └── (your .mp4 videos)
```

## Deploy on GitHub Pages
Settings → Pages → Branch: `main` / root → Save.
